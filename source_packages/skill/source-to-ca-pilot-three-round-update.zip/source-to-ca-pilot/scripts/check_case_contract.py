"""Read-only checks for phase, disclosure and public-field consistency."""
import argparse
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def set_exit_contracts(procedure):
    """Describe pending-work handling; a production engine implements transitions."""
    for stage in procedure['stages']:
        sid = stage['stage_id']
        resolved, deferred = [], {}
        if sid == 'r1_motion':
            deferred = {'motions': 'r1_ruling'}
        elif sid in ['r1_inquiry', 'r1_record_review']:
            resolved = ['objections']
            deferred = {'evidence_rulings': 'r1_ruling', 'motions': 'r1_ruling'}
        elif sid == 'r1_ruling':
            resolved = ['evidence_rulings', 'motions']
        elif sid in ['r2_examination', 'r2_recorded_evidence']:
            resolved = ['objections', 'evidence_rulings']
        stage['exit_requirements'] = {'resolved_queues': resolved, 'deferred_queues': deferred,
                                      'closure_authority': ['R_JUDGE', 'trusted_orchestrator']}
        if sid in ['r1_inquiry', 'r1_record_review']:
            stage['advance_condition'] = '待处理异议解决后可结束；待裁证据与动议带入r1_ruling，不要求本阶段先完成证据裁定。'
        elif sid == 'r1_ruling':
            stage['advance_condition'] = '在本阶段完成待裁证据与动议的处理后，才进入between_rounds。'
        elif resolved:
            stage['advance_condition'] = '本阶段待处理异议及证据裁定完成，由法官或可信编排服务确认结束。'
        elif deferred:
            stage['advance_condition'] = '确认申请与回应结束；待裁动议带入r1_ruling。'
        else:
            stage['advance_condition'] = '法官或可信编排服务确认本阶段任务结束。'


def check_case_contract(case_dir):
    case_dir = Path(case_dir)
    manifest = read(case_dir / 'manifest.json')
    procedure = read(case_dir / 'config/procedure.json')
    policy = read(case_dir / 'config/permissions.json')
    mats = [json.loads(line) for line in (case_dir / 'public/materials.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    stage_map = {s['stage_id']: s for s in procedure['stages']}
    positions = {s['stage_id']: i for i, s in enumerate(procedure['stages'])}
    resolver = {'objections': 'rule_objection', 'evidence_rulings': 'rule_evidence', 'motions': 'rule_motion'}
    for stage in stage_map.values():
        contract = stage['exit_requirements']
        for queue in contract['resolved_queues']:
            assert resolver[queue] in stage['allowed_actions'], (stage['stage_id'], 'unresolvable exit queue', queue)
        for queue, target in contract['deferred_queues'].items():
            assert target in stage_map and positions[target] > positions[stage['stage_id']]
            assert resolver[queue] in stage_map[target]['allowed_actions'], (target, queue)
    initial = procedure['initial_evidence_state']
    rules = {r['material_id']: r for r in policy['material_rules']}
    disclosures = {r['material_id']: r for r in procedure['disclosure_rules']}
    for row in mats:
        assert row['evidence_status'] == initial[row['material_id']], ('initial disclosure mismatch', row['paragraph_id'])
        rule = rules[row['material_id']]
        if initial[row['material_id']] == 'not_yet_disclosed':
            disclosure = disclosures[row['material_id']]
            assert rule['required_event'] and rule['minimum_stage'] == disclosure['earliest_stage']
            assert set(rule['allowed_roles']) == set(disclosure['release_to_role_ids'])
            if disclosure.get('trigger_type', 'lawyer_request') == 'stage_release':
                assert rule['required_event'] == 'stage_release:' + row['material_id']
                assert set(disclosure['release_actor_role_ids']) == {'trusted_orchestrator'}
                assert disclosure['validated_release_required'] is True
            else:
                assert set(disclosure['valid_request_actor_role_ids']) == {'R_DEFENSE', 'R_PROSECUTOR'}
                assert disclosure['validated_request_required'] is True
        else:
            assert rule['required_event'] is None, ('disclosed material still needs disclosure event', row['material_id'])
    public_charges = {c['charge_id'] for c in manifest['charges']}
    assert public_charges
    for objection in procedure['objections']:
        fields = objection['required_fields']
        assert 'issue_id' not in fields, ('hidden issue_id required', objection['objection_id'])
        if 'RELEVANCE' in objection['objection_id']:
            assert {'charge_id', 'relevance_explanation'} <= set(fields)
            assert objection['field_sources']['charge_id'] == 'scoped case payload charges[].charge_id'
            assert objection['field_sources']['relevance_explanation'] == 'lawyer free-text explanation'
    return {'case_id': manifest['case_id'], 'status': 'pass', 'phase_exit_action_consistency': 'pass',
            'initial_and_triggered_disclosure_consistency': 'pass', 'public_objection_field_accessibility': 'pass'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case_dir', type=Path)
    print(json.dumps(check_case_contract(parser.parse_args().case_dir), ensure_ascii=False))
