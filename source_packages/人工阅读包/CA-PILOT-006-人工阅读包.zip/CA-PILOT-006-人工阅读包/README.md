# CA-PILOT-006｜人工阅读包

案件：酒驾致伤中的PAS筛查与后续抽血；版本：0.1.0-authoring。本文件夹独立汇集审阅用阅读稿、文件说明和额外核验附件；主数据包另行提交。

## 阅读顺序

[案件任务](案件任务.md) → [材料阅读稿](materials_reading.md) → [三轮庭审与权限](庭审轮次与权限.md)。

核对事实和角色时看[事实与角色核对稿](FACTS_AND_ROLES.md)；核对条文时看[法律阅读稿](法律阅读稿.md)；争点、原案结果及开发状态见[争点与原案结果](争点与原案结果.md)。

## 主数据包中的文件

主包解压后为 `CA-PILOT-006/`。以下路径均相对此根目录。

| 路径 | 内容 |
|---|---|
| `manifest.json` | 案件编号、版本、法域、来源、日期、任务角色与指控 |
| `public/case.md` | 律师任务说明；属于要求中的主文件 |
| `public/materials.jsonl` | 8项材料、15个摘要段落及来源编号 |
| `public/legal_sources.jsonl` | 19项法律原文、条款、适用版本和快照位置 |
| `role_private/roles.json` | 8个角色的身份、交互风格、知情范围、依据与披露条件 |
| `config/procedure.json` | 三轮阶段、询问对象、动作、证据状态与异议处理 |
| `config/permissions.json` | 角色及阶段权限、材料开放条件和陪审团输入范围 |
| `authoring/world.json` | 16项事实、未知与争议、人物化名及模拟设计 |
| `authoring/provenance.json` | 事实、材料与原文段落的对应 |
| `authoring/outcome_reference.json` | 原案一审结果、上诉处置及日期差异 |
| `authoring/sources/` | 案件及法律原文快照、来源链接和文件哈希索引 |
| `evaluation/issue_outline.json` | 8项争点草稿、关联材料与待核验事项 |
| `evaluation/rubric.json` | 逐项评分标准；当前等待开发试跑后补充 |
| `evaluation/review.json` | 结构核验、开发试跑、法律复核、rubric核验、冻结及正式评测状态 |

## 核验附件

[离线结构与权限核验记录](核验记录/validation.json)记录实际执行的检查；[文件与压缩包哈希](核验记录/package_hashes.json)用于核对两套交付文件。主包 `evaluation/review.json` 保存结构核验摘要及后续工作状态。

## 当前交付阶段

事实与角色材料已编写，开发庭审试跑尚未执行。下一步依次为：开发试跑 → 完善并核验rubric → 冻结版本 → 正式评测。
