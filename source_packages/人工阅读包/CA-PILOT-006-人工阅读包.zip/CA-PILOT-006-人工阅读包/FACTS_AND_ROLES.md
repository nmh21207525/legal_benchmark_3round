# 事实与角色核对稿

**F01**　2000年8月16日，A驾驶的汽车越过双黄线，与另一辆车正面相撞。原文未提供碰撞重建或其他驾驶解释。

性质：reported_event；原文：CL-O2295730-P0005、CL-O2295730-P0007

**F02**　另一辆车的女驾驶员和乘客均因事故遭受严重伤害。未提供两人姓名、伤情诊断及具体医疗资料。

性质：reported_injury；原文：CL-O2295730-P0007

**F03**　B在事故发生后不久到达，看见A眼睛很红、湿润、充血，据此认为A醉酒。A因受伤被送往医院，B未能在现场完成清醒度测试。B不是原文记载的碰撞目击者。

性质：suppression_hearing_testimony；原文：CL-O2295730-P0010

**F04**　在医院，B让A用视线跟随其来回移动的手指，进行眼震测试；原文记载A不能追踪手指，B据此认为其醉酒。没有原始眼震记录、资质资料或其他病因检验。

性质：suppression_hearing_testimony；原文：CL-O2295730-P0011

**F05**　B请求A接受PAS呼气筛查，并告知自愿性质及该测试不能代替被捕后的酒精含量测试义务。A同意该筛查。

性质：reported_advisement_and_consent；原文：CL-O2295730-P0003、CL-O2295730-P0011

**F06**　PAS筛查显示0.09%。B根据观察及测试结果认为A受酒精影响，随后将其逮捕。筛查和逮捕的具体时刻未提供。

性质：suppression_hearing_testimony；原文：CL-O2295730-P0011

**F07**　逮捕后，B告知A须提供血样。A坚持不表示同意抽血，但允许医院工作人员采血。“允许操作”与“表示同意”须保留区别；原文未给出采血逐字对话或具体强制手段。

性质：reported_nonconsent_and_draw；原文：CL-O2295730-P0012

**F08**　原文记载血样经检测，毒理人员确定酒精含量为0.12%。毒理人员姓名、资质、仪器、校准、采血时间和完整检验报告未提供。

性质：reported_laboratory_result；原文：CL-O2295730-P0012

**F09**　原案抽血抑制申请的具体主张为：已有PAS结果，保存酒精证据的紧急需要已消除，后续无令状抽血应排除。此处保留申请论点，不给出原案裁定答案。

性质：reported_motion_theory；原文：CL-O2295730-P0013

**F10**　原文脚注记载，B曾三次尝试取得合格呼气样本，A未封紧嘴唇而妨碍结果。这一证据在正式审判提出，原抑制申请裁定时不在法官面前。

性质：trial_only_evidence；原文：CL-O2295730-P0102、CL-O2295730-P0104

**F11**　原始起诉书列两项：Vehicle Code §23153(a)酒精影响下驾驶致伤，以及§23153(b)血液酒精含量0.08%以上驾驶致伤。其特别指控和先前定罪另存制作参考；本题评两项实体指控。

性质：charging_record；原文：CL-O2295730-P0007、CL-O2295730-P0009

**F12**　来源未给出事故、PAS、逮捕、采血各时刻及相隔时长，也未提供饮酒量、最后饮酒时间、体重或吸收排除率；不能根据0.09与0.12补造饮酒或逆推数据。

性质：record_limit；原文：CL-O2295730-P0010、CL-O2295730-P0011、CL-O2295730-P0012

**F13**　来源未附PAS设备、维护和操作记录、血样流转与实验室原始文件；来源记载医院工作人员采血，但其身份、方法和具体医疗规范未详。

性质：record_limit；原文：CL-O2295730-P0011、CL-O2295730-P0012

**F14**　来源未提供A的定罪前完整个人证言、不在场说法、事故原因辩解或毒理专长；角色不得替A补写承认饮酒、否认驾驶或技术解释。

性质：record_limit；原文：CL-O2295730-P0003、CL-O2295730-P0005、CL-O2295730-P0010、CL-O2295730-P0011、CL-O2295730-P0012

**F15**　来源未提供被害人实时证言或碰撞目击者证词；B在事故后抵达，不能把碰撞全过程变成其亲眼所见。

性质：record_limit；原文：CL-O2295730-P0005、CL-O2295730-P0007、CL-O2295730-P0010

**F16**　原案正式审判持续三天，完整实际开庭日期及逐日证人安排未提供。模拟三轮按本题任务划分。

性质：procedural_history；原文：CL-O2295730-P0015

## 角色知情范围

### R_DEFENSE｜辩护律师

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：按法定要件与材料逐项论证，提出有依据的请求。

### R_PROSECUTOR｜检察官

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：逐项说明举证用途和基础，客观保留证据缺口。

### R_JUDGE｜审判法官

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：中立核验引用、知情与用途，记录裁定理由。

### R_JURY｜陪审团

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：只比较已采纳记录并依已下达指示判断。

### R_SOURCE_RECORD｜获准摘要呈现服务（记录角色）

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：独立案件见闻；任何原始文件或逐字稿的未取得内容

交互风格：仅由可信服务复制获准段落，不新增证人或证言。

### R_OFFICER｜到场警员B

知情事实：F03、F04、F05、F06、F07、F10

未知事项：碰撞亲历；毒理计算、设备校准和血样检验方法；各程序未记载时刻；采血人员资质和具体方法；A饮酒量与最后饮酒时间

交互风格：区分观察、醉酒判断与测试；保留抑制记录和正式审判记录的边界。

```json
{
  "fact_id": "F03",
  "content": "B在事故发生后不久到达，看见A眼睛很红、湿润、充血，据此认为A醉酒。A因受伤被送往医院，B未能在现场完成清醒度测试。B不是原文记载的碰撞目击者。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0010"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F04",
  "content": "在医院，B让A用视线跟随其来回移动的手指，进行眼震测试；原文记载A不能追踪手指，B据此认为其醉酒。没有原始眼震记录、资质资料或其他病因检验。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0011"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F05",
  "content": "B请求A接受PAS呼气筛查，并告知自愿性质及该测试不能代替被捕后的酒精含量测试义务。A同意该筛查。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0003",
    "CL-O2295730-P0011"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F06",
  "content": "PAS筛查显示0.09%。B根据观察及测试结果认为A受酒精影响，随后将其逮捕。筛查和逮捕的具体时刻未提供。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0011"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F07",
  "content": "逮捕后，B告知A须提供血样。A坚持不表示同意抽血，但允许医院工作人员采血。“允许操作”与“表示同意”须保留区别；原文未给出采血逐字对话或具体强制手段。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0012"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F10",
  "content": "原文脚注记载，B曾三次尝试取得合格呼气样本，A未封紧嘴唇而妨碍结果。这一证据在正式审判提出，原抑制申请裁定时不在法官面前。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0102",
    "CL-O2295730-P0104"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": "r2_examination",
  "required_event": "stage_release:M06",
  "disclosure_condition": "仅从第二轮且可信开放事件生效后披露，不能成为第一轮裁定依据",
  "must_preserve_attribution": true
}
```

### R_TOXICOLOGIST｜毒理检验结论（记录角色）

知情事实：F08

未知事项：毒理人员身份和资质；设备、方法、校准和血样流转；饮酒或排除率计算；任何逐字证言

交互风格：仅保留来源记载的0.12%结论；不生成实验室证言。

```json
{
  "fact_id": "F08",
  "content": "原文记载血样经检测，毒理人员确定酒精含量为0.12%。毒理人员姓名、资质、仪器、校准、采血时间和完整检验报告未提供。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0012"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "仅以获准摘要呈现，不接受实时问答",
  "must_preserve_attribution": true
}
```

### R_DEFENDANT｜被告A

知情事实：F05、F07

未知事项：事故原因个人说法；饮酒量、时间和逆推数据；警员醉酒判断的内心依据；毒理检验流程；未记载的警员威胁或抽血对话

交互风格：只述原文已有的PAS告知与自愿筛查及抽血态度，不补个人辩解。

```json
{
  "fact_id": "F05",
  "content": "B请求A接受PAS呼气筛查，并告知自愿性质及该测试不能代替被捕后的酒精含量测试义务。A同意该筛查。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0003",
    "CL-O2295730-P0011"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F07",
  "content": "逮捕后，B告知A须提供血样。A坚持不表示同意抽血，但允许医院工作人员采血。“允许操作”与“表示同意”须保留区别；原文未给出采血逐字对话或具体强制手段。",
  "source_id": "source16",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2295730-P0012"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```
