# 事实与角色核对稿

**F01**　A于2006年5月24日星期三出狱假释，乘火车返回马德拉，在朋友家过第一夜；因朋友要搬家，只能住一夜。

性质：reported_event；原文：CL-O2256789-P0014

**F02**　A在5月25日接受初次假释访谈。B在接收表上标记“Yes”并圈出“PC 290”，注记“To register, 290 PC by 5-31-06”；B作证说这表示她亲自告知A须在五日内登记，并让他5月26日见指定假释官C。

性质：attributed_testimony；原文：CL-O2256789-P0015、CL-O2256789-P0017

**F03**　A于5月25日星期四夜间住在马德拉救助站。

性质：reported_event；原文：CL-O2256789-P0018

**F04**　5月26日，A告诉C自己住在救助站。C要求其登记，并在假释档案中记载须在5月31日前登记；C说救助站离学校太近，A不能继续住在那里。

性质：reported_interaction；原文：CL-O2256789-P0019

**F05**　C安排A住在马德拉县境内一间汽车旅馆，把A及另一名假释人员送去，并要求两人向县警长部门登记。

性质：reported_interaction；原文：CL-O2256789-P0020

**F06**　A于5月26日星期五夜间住在该汽车旅馆。

性质：reported_event；原文：CL-O2256789-P0020

**F07**　C在安置A后的五日内进行强制家访，发现A不在指定房间，个人物品也已带走；C另一天再去，A仍不在。两个家访的具体日期未记载。

性质：reported_observation；原文：CL-O2256789-P0021

**F08**　A于5月27日星期六搬到马德拉市内一名堂表亲家中，并在那里待到6月3日星期六被捕。原文未给出亲属姓名和地址。

性质：reported_event；原文：CL-O2256789-P0022

**F09**　A作证解释搬走是因为有人到旅馆房间绑架、威胁他；他逃脱后仍害怕。这是A的说法，来源没有独立确认绑架、威胁的真实性或详情。

性质：contested_defendant_account；原文：CL-O2256789-P0022

**F10**　原文记载A未尝试联系C，也未登记；此前5月26日见C时尚未向警察或县警长登记。登记机关的原始查询记录未附。

性质：reported_nonregistration；原文：CL-O2256789-P0019、CL-O2256789-P0022

**F11**　A作证说，5月26日见C之前，他曾到马德拉警察部门尝试登记，但因没有预约和身份证明被拒。这是A的转述，没有接待人员证词或窗口记录。

性质：contested_defendant_account；原文：CL-O2256789-P0024

**F12**　A在证言中承认知道登记要求。原文另记载有人提出他以往因未遵守登记要求而违反假释的证据，但未提供每次的具体资料。

性质：attributed_admission_and_history；原文：CL-O2256789-P0025

**F13**　A作证说，大部分人生住在马德拉，家人在当地；此前多次假释出狱后也返回当地。

性质：attributed_testimony；原文：CL-O2256789-P0024

**F14**　原文记载，从出狱次日算到被捕，A已在马德拉十日，经过六个完整工作日：5月25、26日及5月30日至6月2日。5月29日星期一为阵亡将士纪念日假日。法律期限的起算和迁居影响仍须论证。

性质：source_calendar_count；原文：CL-O2256789-P0022

**F15**　原始起诉书引文指控A于2006年6月3日前后在马德拉县故意违反旧版Penal Code §290(a)(1)(A)登记义务；原文只列一项本案实体指控。

性质：charging_record；原文：CL-O2256789-P0032

**F16**　A的登记义务背景为既往性犯罪定罪；原文记载其因马德拉县共同实施强奸定罪服刑后假释，并在本人证言中提到1990年强奸及入室盗窃定罪。没有补入既往犯罪的具体情节。

性质：registration_predicate_history；原文：CL-O2256789-P0014、CL-O2256789-P0024

**F17**　来源未附接收表、假释档案、登记机关查询、预约或身份证件原件；也未附旅馆相关事件的独立记录。不能补写这些文件或把“未附”改成“原案不存在”。

性质：record_limit；原文：CL-O2256789-P0017、CL-O2256789-P0019、CL-O2256789-P0022、CL-O2256789-P0024、CL-O2256789-P0025

**F18**　公开原文的讨论II—III以省略标记呈现；其具体论证未取得。可用事实叙述和讨论I保留，但不能恢复被省略的辩护无效或指示争议内容。

性质：record_limit；原文：CL-O2256789-P0073、CL-O2256789-P0074、CL-O2256789-P0075

**F19**　原案判决记载审判持续三天，裁决于2007年8月16日作出；完整全案庭期表仍未取得。模拟三轮不是原案逐日安排。

性质：procedural_history；原文：CL-O2256789-P0008

## 角色知情范围

### R_DEFENSE｜辩护律师

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：按法定要件与材料逐项论证，提出有依据的请求。

### R_PROSECUTOR｜检察官

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：逐项说明举证用途和基础，客观保留证据缺口。

### R_JUDGE｜审判法官

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：中立核验引用、知情与用途，记录裁定理由。

### R_JURY｜陪审团

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：不得取得其他角色私卡、底稿或原案结果。

交互风格：只比较已采纳记录并依已下达指示判断。

### R_SOURCE_RECORD｜获准摘要呈现服务（记录角色）

知情事实：无先验事实；按权限取得披露材料或庭审记录。

未知事项：独立案件见闻；任何原始文件或逐字稿的未取得内容

交互风格：仅由可信服务复制获准段落，不新增证人或证言。

### R_INTAKE_AGENT｜初次访谈假释官B

知情事实：F02

未知事项：A后来迁居及登记经过；C的家访；旅馆威胁及警察窗口接待；未取得的接收表原件

交互风格：区分表格记载与本人所作告知，只回答自己初访范围。

```json
{
  "fact_id": "F02",
  "content": "A在5月25日接受初次假释访谈。B在接收表上标记“Yes”并圈出“PC 290”，注记“To register, 290 PC by 5-31-06”；B作证说这表示她亲自告知A须在五日内登记，并让他5月26日见指定假释官C。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0015",
    "CL-O2256789-P0017"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

### R_ASSIGNED_AGENT｜指定假释官C

知情事实：F04、F05、F07

未知事项：B初访的亲历过程；A搬离的真实原因；警察窗口是否拒绝A；家访的具体未记载日期；登记机关完整查询结果

交互风格：准确区分A告诉自己的住宿情况、自己的安排与家访所见。

```json
{
  "fact_id": "F04",
  "content": "5月26日，A告诉C自己住在救助站。C要求其登记，并在假释档案中记载须在5月31日前登记；C说救助站离学校太近，A不能继续住在那里。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0019"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F05",
  "content": "C安排A住在马德拉县境内一间汽车旅馆，把A及另一名假释人员送去，并要求两人向县警长部门登记。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0020"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F07",
  "content": "C在安置A后的五日内进行强制家访，发现A不在指定房间，个人物品也已带走；C另一天再去，A仍不在。两个家访的具体日期未记载。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0021"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

### R_DEFENDANT｜被告A

知情事实：F01、F02、F03、F04、F05、F06、F08、F09、F10、F11、F12、F13、F16

未知事项：B或C的未披露内心；绑架者身份、具体原话与独立证明；接待人员身份和窗口逐字对话；新的登记记录及日期

交互风格：可陈述原文归于本人的经历和说法，保持来源中的争议归属。

```json
{
  "fact_id": "F01",
  "content": "A于2006年5月24日星期三出狱假释，乘火车返回马德拉，在朋友家过第一夜；因朋友要搬家，只能住一夜。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0014"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F02",
  "content": "来源记载B亲自告知A须在五日内登记，并让他5月26日见C；本角色不取得B在接收表上的内部标记。",
  "source_id": "source15",
  "fact_scope": "source-supported partial fact, excluding other role internal records",
  "source_locators": [
    "CL-O2256789-P0015",
    "CL-O2256789-P0017"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F03",
  "content": "A于5月25日星期四夜间住在马德拉救助站。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0018"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F04",
  "content": "来源记载A告诉C自己住在救助站，C要求登记，并说A因救助站离学校太近而不能继续居住；本角色不取得C档案中的内部注记。",
  "source_id": "source15",
  "fact_scope": "source-supported partial fact, excluding other role internal records",
  "source_locators": [
    "CL-O2256789-P0019"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F05",
  "content": "C安排A住在马德拉县境内一间汽车旅馆，把A及另一名假释人员送去，并要求两人向县警长部门登记。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0020"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F06",
  "content": "A于5月26日星期五夜间住在该汽车旅馆。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0020"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F08",
  "content": "A于5月27日星期六搬到马德拉市内一名堂表亲家中，并在那里待到6月3日星期六被捕。原文未给出亲属姓名和地址。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0022"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F09",
  "content": "A作证解释搬走是因为有人到旅馆房间绑架、威胁他；他逃脱后仍害怕。这是A的说法，来源没有独立确认绑架、威胁的真实性或详情。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0022"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F10",
  "content": "原文记载A未尝试联系C，也未登记；此前5月26日见C时尚未向警察或县警长登记。登记机关的原始查询记录未附。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0019",
    "CL-O2256789-P0022"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F11",
  "content": "A作证说，5月26日见C之前，他曾到马德拉警察部门尝试登记，但因没有预约和身份证明被拒。这是A的转述，没有接待人员证词或窗口记录。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0024"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F12",
  "content": "A在原案证言中承认知道登记要求；本知识点不提供以往假释违规的未知细节。",
  "source_id": "source15",
  "fact_scope": "source-supported partial fact, excluding other role internal records",
  "source_locators": [
    "CL-O2256789-P0025"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F13",
  "content": "A作证说，大部分人生住在马德拉，家人在当地；此前多次假释出狱后也返回当地。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0024"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```

```json
{
  "fact_id": "F16",
  "content": "A的登记义务背景为既往性犯罪定罪；原文记载其因马德拉县共同实施强奸定罪服刑后假释，并在本人证言中提到1990年强奸及入室盗窃定罪。没有补入既往犯罪的具体情节。",
  "source_id": "source15",
  "fact_scope": "listed source-bound fact",
  "source_locators": [
    "CL-O2256789-P0014",
    "CL-O2256789-P0024"
  ],
  "knowledge_basis": "Only source-attributed personal interaction, observation, statement or recorded conclusion.",
  "available_from_stage": null,
  "required_event": null,
  "disclosure_condition": "获准阶段传唤后作来源范围内回答；A另须自愿选择作证",
  "must_preserve_attribution": true
}
```
